package com.ttn

/*
Groovy Truth: if('test') { printlnn "test evaluated to true inside if" } try replacing test with various objects and observe its behaviour.

"Test"
'null'
null
100
0
empty list
list with all vaues as null List list = new ArrayList()
Write a class HourMinute where the class stores hours and minutes as separate fields. Overload + and - operator operator for this class

*/




class Question5 {


    static void main(args){
       String name=null
        if(name)
        println("test evaluated to true inside if")


        List list=new ArrayList()
        if(list)
            println("true")

        HourMinute hm=new HourMinute(2,20)
        HourMinute hm1=new HourMinute(2, 50)
        HourMinute hmResult=hm1+hm
        HourMinute hmResultMinus=hm1-hm

        println("Hours:$hmResult.hours,Minutes:$hmResult.minutes")
        println("Hours:$hmResultMinus.hours,Minutes:$hmResultMinus.minutes")


    }
}

class HourMinute{
    int hours;
    int minutes;

   HourMinute (int hours,int minutes){
       this.hours=hours
       this.minutes=minutes
   }

    HourMinute plus(HourMinute hourMinute){
            return new HourMinute(this.hours + hourMinute.hours,this.minutes+hourMinute.minutes)
    }

    HourMinute minus(HourMinute hourMinute){
        return new HourMinute(this.hours - hourMinute.hours,this.minutes-hourMinute.minutes)
    }
}
