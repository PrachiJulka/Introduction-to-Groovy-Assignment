package com.ttn
//Write a method which removes all the white
// spaces in a file and writes the output to another file.
// Suppose white space characters are Space, Tab and Enter
class Question10 {

    static void main(args){
    Question10 question10=new Question10()
        question10.removeWhiteSpaces()

    }

    void removeWhiteSpaces(){

        File file=new File("src/File.txt")
        File removeWhiteSpaces=new File("src/RemoveWhiteSpaces")

        file.eachLine {
            removeWhiteSpaces << it.replaceAll("\\s","")
        }

    }
}
