package com.ttn
/*
Extend the Person class in Groovy Add following fields to it:
 empId, company, salary Access the fields in all known ways: like through getter
 , by dot operator, by @ operator.*/

class PersonGroovy extends Person{
    int empId;
    String company;
    long salary;
}



public class Question2{

    static void main(args) {

        def personGroovy=new PersonGroovy();
        personGroovy.empId=21;
        personGroovy.company="To The New";
        personGroovy.salary=20000;
        personGroovy.name="Prachi";
        personGroovy.age=24;
        personGroovy.gender="Female";
        personGroovy.address="Delhi";

        println(personGroovy.empId);
        println(personGroovy.company);
        println(personGroovy.salary);
        println(personGroovy.name);
        println(personGroovy.age);
        println(personGroovy.gender);
        println(personGroovy.address);

    }



}