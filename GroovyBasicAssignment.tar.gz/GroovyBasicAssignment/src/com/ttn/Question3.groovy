package com.ttn
/*
Print this pattern using groovy:


*
**
****
********
*/

class Question3 {

            static void main(args){
                int num
                (0..3).each {
                     num=it*it

                    (0..num).each {
                        print "*"
                    }
                   println("")
                }

            }


}
