package com.ttn
//Combine content of all the files in a specific directory to another new file

class Question8 {


    static void main(args){

        File src1 = new File("src/File1.txt")
        File src2=new File("src/File2.txt")
        File dst = new File("src/File.txt")
        dst << src2.text
        dst << src1.text

    }


}
