package com.ttn
//Create a file which contains all the odd numbered lines of a given file.
// Each line should be numbered at the beginning of line viz : 1, 3, 5.....
class Question9 {

static void main(args){
    File src = new File("src/File3")
    File dst = new File("src/OddFile")

    int index=1;
    src.eachLine {
        if(index%2!=0) {
            dst << ("${index} ${it} \n")
        }


        index++
    }

  }

}
