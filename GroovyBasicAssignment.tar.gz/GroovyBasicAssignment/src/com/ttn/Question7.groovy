package com.ttn

//Write a closure which checks
// if a value is contained within a list where the closure accepts two parameters

class Question7 {

    static void main(args){

        Scanner sc=new Scanner(System.in)

        List list=[1,2,3,4,5]


        def contains={List list1,a->
            if(list1.contains(a))
            {
                println("it contains")
            }
            else{
                println("doesnt contain")
            }
        }

        println("Enter number to search in a list")

        contains(list,sc.nextInt())

        }

}
