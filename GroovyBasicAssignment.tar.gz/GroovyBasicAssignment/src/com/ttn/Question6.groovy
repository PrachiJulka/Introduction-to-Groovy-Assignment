package com.ttn

//Print multiple of 3 upto 10 terms in at least
//three different ways using groovy special methods


class Question6 {

    static void main(args){

        println("Multiple Of 3 with 3 different methods")
        println("Method 1 : ")
        (1..10).each {

            println(it*3)
        }

        println("Method 2:  ")
        1.upto(10) {
            println (3*it)
        }

        println("Method 3:")
        for (number in 1..10 ) {
            println (number*3)
        }
    }

}
