package com.ttn

import groovy.transform.ToString

//GString... override the toString() of the
// Person class to return something like... "Sachin is a man aged 24 who lives at Delhi.
// He works for Intelligrape with employee id 12 and draws $$$$$$$ lots of money !!!!."
class Question4 {

    static void main(args){
       // PersonGroovy1 personGroovy1=new PersonGroovy1();
        def personGroovy1=new PersonGroovy1();
        personGroovy1.empId=21;
        personGroovy1.company="To The New";
        personGroovy1.salary=20000;
        personGroovy1.name="Sachin";
        personGroovy1.age=24;
        personGroovy1.gender="Male";
        personGroovy1.address="Delhi";
        println(personGroovy1)
    }


}

class PersonGroovy1 extends Person{
    int empId;
    String company;
    long salary;


    @Override
    public String toString() {
        return "${name} is a man aged ${age} who lives at ${address}." +
                "He works for ${company} with employee Id ${empId} and draws ${salary} money!!!. "
    }
}

