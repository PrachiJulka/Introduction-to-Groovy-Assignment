package com.ttn



//Make copy of an image type file byte by byte

class Question11 {

    static void main(args) {
       File src = new File("src/Beautiful_HD_Quote_Wallpaper.jpg")
            new File("src/copy.jpg").withOutputStream { out ->
                out.write src.readBytes()
            }

    }

}


