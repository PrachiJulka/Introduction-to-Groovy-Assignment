package com.ttn;

//Create a class in Java along with follwing fields. classname: Person fields: name, age, gender, address Access the fields in all known ways: like through getter , by dot operator

class Person{
    //name, age, gender, address
    private String name;
    private int age;
    private String gender;
    private String address;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }



}



public class Question1{

    public static void main(String[] args){

        Person person=new Person();

        person.setName("Rachel");
        person.setAge(24);
        person.setGender("Female");
        person.setAddress("Delhi");

        System.out.println("Name: "+person.getName());
        System.out.println("Age: "+person.getAge());
        System.out.println("Gender: "+person.getGender());
        System.out.println("Address: "+person.getAddress());


    }



}